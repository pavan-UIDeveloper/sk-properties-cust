import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-property-serch',
  templateUrl: './property-serch.component.html',
  styleUrls: ['./property-serch.component.css']
})
export class PropertySerchComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
