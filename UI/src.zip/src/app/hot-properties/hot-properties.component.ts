import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hot-properties',
  templateUrl: './hot-properties.component.html',
  styleUrls: ['./hot-properties.component.css']
})
export class HotPropertiesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
