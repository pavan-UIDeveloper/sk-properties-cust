import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';

import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { AboutUsComponent } from './about-us/about-us.component';
import { PropertiesComponent } from './properties/properties.component';
import { ContactUsComponent } from './contact-us/contact-us.component';
import { LoginComponent } from './login/login.component';
import { HeaderComponent } from './header/header.component';
import { PropertySerchComponent } from './home/property-serch/property-serch.component';
import { BannerComponent } from './home/banner/banner.component';
import { HotPropertiesComponent } from './hot-properties/hot-properties.component';
import { Routes, RouterModule } from '@angular/router';

const route:Routes = [
  {path:'',component:HomeComponent},
  {path:'login',component:LoginComponent},
  {path:'aboutus',component:AboutUsComponent},
  {path:'contactus',component:ContactUsComponent},
  {path:'properties',component:PropertiesComponent,children:[
   // {path:'forsale',}
  ]}
]

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    AboutUsComponent,
    PropertiesComponent,
    ContactUsComponent,
    LoginComponent,
    HeaderComponent,
    PropertySerchComponent,
    BannerComponent,
    HotPropertiesComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    RouterModule.forRoot(route)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
